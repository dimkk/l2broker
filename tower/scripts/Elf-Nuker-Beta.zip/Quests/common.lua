function Nuke_AddSkill(id, range)
	local it = L2TConfig.NukeSetting();
	local SCONFIG = L2TConfig.GetConfig();
	it.meHpCondition = L2TConfig.ENukeCondition.NC_ALWAYS;
	it.meMpCondition = L2TConfig.ENukeCondition.NC_ALWAYS;
	it.meHpValue = 100;
	it.meMpValue = 100;
	it.useRepeat = true;
	it.requireTarget = true;
	it.skillId = id;
	it.targetCount = 1;
	it.targetHpCondition = L2TConfig.ENukeCondition.NC_ALWAYS;
	it.targetHpValue = 100;
	it.targetRange = range;
	it.useEvery = 0; --autodetect
	SCONFIG.nuke.skills:Add(it);
end;

function EnableAttackRange(range)
	local SCONFIG = L2TConfig.GetConfig();
	SCONFIG.nuke.skills:Clear();
	Nuke_AddSkill(1177, range*2); --Wind Strike
	SCONFIG.nuke.enabled = true;
end;

function EnableAttack()
	EnableAttackRange(600);
end;


function DisableAttack()
	local SCONFIG = L2TConfig.GetConfig();
	SCONFIG.nuke.enabled = false;
	SCONFIG.nuke.skills:Clear();
end;

function PreSetup()
	SCONFIG.potions.enabled = true;
	SCONFIG.potions.HP.enabled = true;
	SCONFIG.potions.HP.LesserHealingPotion.DamagePercent = 10;
	SetPause(false);
	LearnAllSkills();
end;

function CountMonstersInRange(range)
	local me = GetMe();
	local l = GetMonsterList();
	local c = 0;
		
	for user in l.list do 
		if ((user:IsAlikeDeath() == false) and (user:GetRangeTo(me)<range)) then
			c = c + 1;
		end;		
	end;
	return c;
end;

function KillTarget()
	local t = GetTarget();
	if (t == nil) then
		return true;
	end;
	if ((t:IsValid() == false) or (t:IsAlikeDeath() == true)) then
		return true;
	end;
	--wylacz targetowanie, wlacz attack...
	EnableAttackRange(10000);
	SCONFIG.targeting.option = L2TConfig.ETargetingType.TT_OFF;
	local paused = IsPaused();
	SetPause(false);
	repeat
		ClearTargets();
		Target(t);
		Sleep(500);
	until (t:IsValid() == false) or (t:IsAlikeDeath() == true);
	DisableAttack();
	SetPause(paused);
	return true;
end;

function KillEveryooneWhoAttacks(u)
	local monsters = GetMonsterList();
	local t = nil;
	repeat
		t = nil;
		for user in monsters.list do 
			if (user:IsEnemy() and user:GetTarget() == u:GetId() ) then
				t = user;
				break;
			end;
		end;
		if (t ~= nil) then
			Target(t);
			KillTarget();
		end;
	until t == nil;
end;

function AddPathPoint(X, Y, Z, Range)
	local tmpPoint = L2TConfig.L2PathPoint();
	tmpPoint.X = X;
	tmpPoint.Y = Y;
	tmpPoint.Z = Z;
	tmpPoint.range = Range;
	tmpPoint.type = L2TConfig.ETargetingRangeType.TRT_CIRCLE;
	SCONFIG.targeting.pathPoints:Add(tmpPoint);
end;