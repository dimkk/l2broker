dofile (GetDir() .. "\\scripts\\Quests\\common.lua");
SCONFIG = L2TConfig.GetConfig();
moveDistance = 50;
PreSetup();
ShowToClient("Q3", "Quest Searching for the Mysterious Power - Started");
MoveTo(-111432, 255835, -1443, moveDistance);
MoveTo(-111399, 255866, -1443, moveDistance);
TargetNpc("Shannon", 32974);
Talk();

ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=3&option=1", "[532201]");
ClickAndWait("menu_select?ask=10322&reply=1", "\"And why would you do that?\"");
ClickAndWait("quest_accept?quest_id=10322", "\"I just want to get stronger.\"");
ClearTargets();
Sleep(500);

MoveTo(-111403, 255821, -1443, moveDistance);
MoveTo(-111730, 255439, -1443, moveDistance);
MoveTo(-112055, 255050, -1453, moveDistance);
MoveTo(-112191, 254531, -1503, moveDistance);
MoveTo(-111703, 254072, -1672, moveDistance);
MoveTo(-110797, 253624, -1787, moveDistance);
MoveTo(-110761, 253496, -1736, moveDistance);

TargetNpc("Evain", 33464);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=0&option=1", "[532202]");
ClearTargets();
Sleep(500);

MoveTo(-110761, 253496, -1736, moveDistance);

SCONFIG.targeting.option = L2TConfig.ETargetingType.TT_RANGE_FROM_POINT;
SCONFIG.targeting.centerPoint.X = -110761;
SCONFIG.targeting.centerPoint.Y = 253496;
SCONFIG.targeting.centerPoint.Z = -1736;
SCONFIG.targeting.rangeType = L2TConfig.ETargetingRangeType.TRT_CIRCLE;
SCONFIG.targeting.range = 600;

EnableAttack();
SetPause(false);
repeat
 Sleep(1000);
until GetQuestManager():GetQuestProgress(10322) == 3;
DisableAttack();
SetPause(true);
ClearTargets();

MoveTo(-110761, 253496, -1736, moveDistance);

TargetNpc("Evain", 33464);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=2&option=1", "[532202]");
ClearTargets();
Sleep(500);
MoveTo(-110767, 253471, -1739, moveDistance);
MoveTo(-110725, 253646, -1791, moveDistance);

TargetNpc("Newbie Helper", 32981);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("menu_select?ask=10322&reply=1", "\"I'll do anything to get stronger!\"");
ClearTargets();
Sleep(500);

MoveTo(-110761, 253496, -1736, moveDistance);

EnableAttack();
SetPause(false);
repeat
 Sleep(1000);
until GetQuestManager():GetQuestProgress(10322) == 6;
DisableAttack();
SetPause(true);
ClearTargets();
SCONFIG.targeting.option = L2TConfig.ETargetingType.TT_OFF;

MoveTo(-110761, 253496, -1736, moveDistance);

TargetNpc("Evain", 33464);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=5&option=1", "[532202]");
ClearTargets();
Sleep(500);
UseItem(7816); -- Apprentice Adventurer's Staff
Sleep(500);
ShowToClient("Q3", "Quest Searching for the Mysterious Power - Finished");