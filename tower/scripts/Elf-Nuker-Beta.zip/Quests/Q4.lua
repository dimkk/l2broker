dofile (GetDir() .. "\\scripts\\Quests\\common.lua");
SCONFIG = L2TConfig.GetConfig();
moveDistance = 50;
PreSetup();
ShowToClient("Q4", "Quest Going into a Real War, Let's Go to the Underground Traning Field! - Started");
LearnAllSkills();
MoveTo(-110761, 253496, -1736, moveDistance);
TargetNpc("Evain", 33464);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("menu_select?ask=10323&reply=1", "\"Ready!\"");
ClickAndWait("quest_accept?quest_id=10323", "\"I'll put them down.\"");

MoveTo(-110770, 253478, -1740, moveDistance);
MoveTo(-110736, 253611, -1787, moveDistance);
MoveTo(-110715, 253632, -1792, moveDistance);
MoveTo(-110646, 253619, -1791, moveDistance);
MoveTo(-110406, 253185, -1806, moveDistance);
MoveTo(-110312, 252946, -1841, moveDistance);
MoveTo(-110302, 252657, -1975, moveDistance);
MoveTo(-110342, 252558, -1987, moveDistance);
MoveTo(-110342, 252558, -1987, moveDistance);
MoveTo(-110401, 252503, -1990, moveDistance);

TargetNpc("Holden", 33194);
Talk();
Click("menu_select?ask=-3500&reply=1", "Move to the Training Grounds Underground Facility.");
WaitForTeleport();

SCONFIG.targeting.option = L2TConfig.ETargetingType.TT_RANGE_FROM_CHAR;
SCONFIG.targeting.rangeType = L2TConfig.ETargetingRangeType.TRT_CIRCLE;
SCONFIG.targeting.range = 600;

MoveTo(-114057, 248284, -7878, moveDistance);
EnableAttack();
SetPause(false);
repeat
 Sleep(500);
until CountMonstersInRange(SCONFIG.targeting.range) == 0;
SetPause(true);

MoveTo(-114865, 248288, -7878, moveDistance);
SetPause(false);
repeat
 Sleep(500);
until CountMonstersInRange(SCONFIG.targeting.range) == 0;
SetPause(true);

MoveTo(-114865, 248288, -7878, moveDistance);

repeat
Sleep(500);
until GetQuestManager():GetQuestProgress(10323) == 3;

TargetNpc("Guard", 33021);
Talk();
ClickAndWait("menu_select?ask=10323&reply=1", "\"No, please tell me.\"");
ClearTargets();
ActivateSoulShot(1835, true); -- Soulshot: No Grade
ActivateSoulShot(3947, true); -- Blessed Spiritshot : No Grade
ActivateSoulShot(2509, true); -- Spiritshot : No Grade
Sleep(500);
repeat
TargetNpc("Guard", 33021);
Talk();
ClearTargets();
Sleep(1000);
until CountMonstersInRange(SCONFIG.targeting.range) > 0;

MoveTo(-114865, 248288, -7878, moveDistance);
SetPause(false);
repeat
 Sleep(500);
until CountMonstersInRange(SCONFIG.targeting.range) == 0;
SetPause(true);

MoveTo(-114057, 248284, -7878, moveDistance);
EnableAttack();
SetPause(false);
repeat
 Sleep(500);
until CountMonstersInRange(SCONFIG.targeting.range) == 0;
SetPause(true);
DisableAttack();
SCONFIG.targeting.option = L2TConfig.ETargetingType.TT_OFF;

MoveTo(-114012, 247724, -7877, moveDistance);
TargetNpc("Aymen", 33193);
Talk();
Click("menu_select?ask=-3502&reply=1", "I need to return back to town.");
ClearTargets();

repeat
 Sleep(500);
until GetQuestManager():GetQuestProgress(10323) == 8;
-- Quest state changed, ID: 10323, STATE: 8

MoveTo(-110406, 252499, -1990, moveDistance);
MoveTo(-110380, 252486, -1992, moveDistance);
MoveTo(-110268, 252671, -1968, moveDistance);
MoveTo(-110318, 253017, -1832, moveDistance);
MoveTo(-110654, 253621, -1792, moveDistance);
MoveTo(-111008, 253700, -1771, moveDistance);
MoveTo(-112046, 254258, -1566, moveDistance);
MoveTo(-112127, 254548, -1490, moveDistance);
MoveTo(-112138, 254690, -1473, moveDistance);
MoveTo(-112047, 255011, -1451, moveDistance);
MoveTo(-111990, 255103, -1441, moveDistance);
MoveTo(-111984, 255128, -1442, moveDistance);
MoveTo(-111412, 255832, -1444, moveDistance);
TargetNpc("Shannon", 32974);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=7&option=1", "[532302]");
ClickAndWait("menu_select?ask=10323&reply=1", "\"I can use shots now... that's pretty cool.\"");
ClearTargets();
ShowToClient("Q4", "Quest Going into a Real War, Let's Go to the Underground Traning Field! - Finished");