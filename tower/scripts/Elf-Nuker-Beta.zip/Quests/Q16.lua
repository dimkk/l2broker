dofile (GetDir() .. "\\scripts\\Quests\\common.lua");
SCONFIG = L2TConfig.GetConfig();
moveDistance = 80;
PreSetup();
ShowToClient("Q16", "Quest Seeker Escort - Started");
MoveTo(-110628, 238388, -2926, moveDistance);
TargetNpc("Def ", 33453);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=2&option=1", "[536501]");
ClickAndWait("menu_select?ask=10365&reply=1", "\"Er, can I help you?\"");
ClickAndWait("quest_accept?quest_id=10365", "\"Sure.\"");
ClearTargets();
SetPause(false);
Sleep(3000);
-- Find my "pet", and follow him
local npc = GetNpcList();
local pet = nil;
for user in npc.list do 
	if ((user:GetNpcId() == 32988) and user:GetNickName() == GetMe():GetName()) then
			pet = user;
	end;
end;

repeat
MoveTo(pet:GetLocation(), 60);
KillEveryooneWhoAttacks(pet);
KillEveryooneWhoAttacks(GetMe());
Sleep(200);
until pet:GetRangeTo(-112305, 240212, -2920) < 60;
Sleep(500);
MoveTo(-112275, 240219, -2925, 40);
ClearTargets();
TargetNpc("Ye Sagira Teleport Device", 33188);
Talk();
Click("menu_select?ask=-3524&reply=1", "The 5th Exploration Zone");
WaitForTeleport();
Sleep(500);
local pet = nil;
repeat
local npc = GetNpcList();
for user in npc.list do 
	if ((user:GetNpcId() == 32988) and user:GetNickName() == GetMe():GetName()) then
			pet = user;
	end;
end;
Sleep(500);
until pet ~= nil;

repeat
MoveTo(pet:GetLocation(), 60);
KillEveryooneWhoAttacks(pet);
KillEveryooneWhoAttacks(GetMe());
Sleep(200);
until pet:IsValid() == false;
SetPause(true);
MoveTo(-111800, 231776, -3160, 40);
TargetNpc("Sebion", 32978);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=13&option=1", "[536502]");
ClickAndWait("menu_select?ask=10365&reply=3", "\"I'll leave you two to it.\"");
ClearTargets();
Sleep(500);
ShowToClient("Q16", "Quest Seeker Escort - Finished");
