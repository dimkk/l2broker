dofile (GetDir() .. "\\scripts\\Quests\\common.lua");
SCONFIG = L2TConfig.GetConfig();
moveDistance = 50;
PreSetup();
ShowToClient("Q10", "Quest Backup Seekers - Started");

MoveTo(-117968, 255841, -1327, moveDistance);
TargetNpc("Kakai", 30565);
Talk();
ClickAndWait("talk_select", "Quest.");
ClickAndWait("quest_choice?choice=3&option=1", "[532901]");
ClickAndWait("menu_select?ask=10329&reply=1", "Ask what you should do.");
ClickAndWait("quest_accept?quest_id=10329", "Go help in Ye Sagira.");
ClearTargets();
Sleep(500);
MoveTo(-117968, 255841, -1327, moveDistance);
MoveTo(-117688, 255773, -1305, moveDistance);
MoveTo(-117066, 255490, -1298, moveDistance);
MoveTo(-116570, 255262, -1443, moveDistance);
MoveTo(-115853, 254814, -1511, moveDistance);
MoveTo(-114883, 254664, -1528, moveDistance);
MoveTo(-114693, 254432, -1530, moveDistance);
MoveTo(-114566, 254263, -1531, moveDistance);

TargetNpc("Newbie Helper", 33454);
Talk();
QuestReply("menu_select?ask=-7&reply=2");
ClearTargets();
Sleep(500);

MoveTo(-114566, 254263, -1531, moveDistance);
MoveTo(-114480, 254188, -1524, moveDistance);
MoveTo(-114307, 254117, -1528, moveDistance);
MoveTo(-114154, 253974, -1529, moveDistance);
MoveTo(-114116, 253465, -1525, moveDistance);
MoveTo(-114082, 253015, -1525, moveDistance);
MoveTo(-114082, 252700, -1547, moveDistance);
MoveTo(-114073, 252551, -1561, moveDistance);

TargetNpc("Apprentice", 33124);
Talk();
Click("menu_select?ask=-3530&reply=1", "\"Why not?\"");
ClearTargets();
Sleep(500);
moveDistance = 80;
MoveTo(-114073, 252551, -1561, moveDistance);
MoveTo(-114073, 252551, -1545, moveDistance);
MoveTo(-114400, 251615, -1651, moveDistance);
MoveTo(-114180, 251022, -1733, moveDistance);
MoveTo(-114002, 250966, -1762, moveDistance);
MoveTo(-113807, 250905, -1796, moveDistance);
MoveTo(-113608, 250842, -1832, moveDistance);
MoveTo(-113343, 250758, -1872, moveDistance);
MoveTo(-113096, 250680, -1904, moveDistance);
MoveTo(-113083, 250676, -1906, moveDistance);
MoveTo(-111962, 250396, -2114, moveDistance);
MoveTo(-110251, 250222, -2790, moveDistance);
MoveTo(-108639, 249332, -3064, moveDistance);

moveDistance = 30;
MoveTo(-107744, 248800, -3200, moveDistance);
UseSkill(9210, false, false); -- Dismount
TargetNpc("Atran", 33448);
Talk();
ClickAndWait("talk_select", "Quest");
ClickAndWait("quest_choice?choice=0&option=1", "[532902]");
ClickAndWait("menu_select?ask=10329&reply=2", "\"Kakai sent me.\"");
ClearTargets();
Sleep(500);
UseItem(906); -- Necklace of Knowledge
Sleep(500);
UseItem(875); -- Ring of Knowledge
Sleep(500);
ShowToClient("Q10", "Quest Backup Seekers - Finished");
